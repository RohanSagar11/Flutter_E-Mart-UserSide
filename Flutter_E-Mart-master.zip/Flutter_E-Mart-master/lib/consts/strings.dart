const appname = "eMart";
const appversion = "Version 1.0.0";
const credits = "@Baaba Devs";
